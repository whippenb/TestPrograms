﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ElizaTest
{
    class Program
    {
        public static String name { set; get; }         //stored name
        public static String filename { set; get; }     //xml file name
        public static XDocument xDoc { get; set; }
        public static int counter { get; set; }         //count phone loops

        public void SAY (String output)                 
        {
            Console.WriteLine(removeBrackets(output));
            xDoc.Root.Element("SESSION" + counter).Add(new XElement("SAY", output));
        }

        public String ASK (String question, String type)
        {
            Console.WriteLine(removeBrackets(question));
            String response = Console.ReadLine();
            xDoc.Root.Element("SESSION" + counter).Add(new XElement("ASK", new XAttribute("NAME", type), new XAttribute("RESPONSE", response), question));
            return response;

        }

        public String removeBrackets(String s)          //Obviously I didn't want it to have the brackets when I was printing it.  
        {
            while (s.Contains("}")){
                s = s.Remove(s.IndexOf("{"), (s.IndexOf("}") - s.IndexOf("{")) + 2);
            }
            return s;
        }

        public void WorkFlow()                          //Split the workflow into sections
        {
            Introduction();
            EndCall(Transfer(Questions()));

        }

        public void Introduction()                      //Intro section as you would expect
        {
            string inputs;          //I know this has limitations
            SAY("{S_Hello} Hello, this is Eliza Corp calling.");
            name = ASK("{P_Name} What is your name?", "NAME");
            inputs = ASK("{NAME} " + name + "{P_Questions} , may I ask you a few questions?", "QUESTIONS");
            if(inputs == "no" || inputs == "No")
            {
                inputs = ASK("{P_Busy} Are you too busy to answer my questions?", "Busy");
                if(inputs == "yes" || inputs == "Yes")
                {
                    SAY("{S_TooBad} Too bad...");
                    return;
                }else
                {
                    inputs = ASK("{P_Problem} Well, what is the problem then?", "Problem");
                    SAY("{S_OhStopIt} Oh stop it...");
                    return;
                }
            }

        }

        public int Questions()                      //Questions section.  I could have made it return a bool instead but I thought it would be easier to edit this way if someone were to add onto it
        {
            string inputs;
            SAY("{S_Questions} Great! The following questions are about the interview process you just went through");
            inputs = ASK("{P_InterviewLength} How many minutes did the interview take?", "INTERVIEW_LENGTH");           //I changed this since people would probably put "minutes" after a number otherwise
            try
            {
                int minutes = Int32.Parse(inputs);
                if (minutes < 30)
                {
                    SAY("{S_LessThan30} That's a pretty short interview");
                }
                else if (minutes > 60)
                {
                    SAY("{S_OverHour} That must have been brutal...");
                }
                else
                {
                    inputs = ASK("{P_WentWell} Do you think it went well?", "WENT_WELL");
                }
            }
            catch                                   //Needed a try/catch for the number scenario
            {
                SAY("Not a number");
                inputs = ASK("{P_WentWell} Do you think it went well?", "WENT_WELL");
            }
            inputs = ASK("{P_RememberInterviewers} Do you remember whom you spoke with?", "REMEMBER_INTERVIEWERS");
            if (inputs == "no" || inputs == "No")
            {
                inputs = ASK("{P_ForgotToIntroduce} Did the interviewers forget to introduce themselves?", "FORGOT_TO_INTRODUCE");
                if (inputs == "no" || inputs == "No")
                {
                    inputs = ASK("{P_ShouldHire} And you think we should hire you?", "SHOULD_HIRE");
                    if (inputs == "no" || inputs == "No")
                    {
                        SAY("{S_ShouldHire_N} Don't be so hard on yourself. Interviews can be stressful.");
                    }
                    else
                    {
                        SAY("{S_ShouldHire_Y} We'll see about that...");
                    }
                }
                else
                {
                    SAY("{S_ForgotToIntroduce_Y} O-o, someone's in trouble.");
                }
            }
            else
            {
                inputs = ASK("{P_WhomSpokeTo} Whom did you speak with?", "WHO_INTERVIEWED");
                inputs = ASK("{P_AnsweredQuestions} Did they answer all your questions?", "ANSWERED_ALL_QUESTIONS");
                if (inputs == "yes" || inputs == "Yes")
                {
                    SAY("{S_Great} Great!");
                    return 1;
                }

            }

            return 0;
        }

        public int Transfer(int passed)                 //Transfer section.  Again, I made it an int so you could add to it.  
        {
            string inputs;
            if (TransferHours())
            {
                if(passed == 0)
                {
                    inputs = ASK("{P_TransferWithQuestions} Would you like to be transferred to eliza so that someone there could answer your questions", "TRANSFER_AQ");
                    if(inputs == "no" || inputs == "No")
                    {
                        SAY("{S_Alright} Alright...");
                        return 0;
                    }
                    else
                    {
                        SAY("{S_Transferring} Transferring now...");
                        Transfer(true);
                        return 1;
                    }
                }else
                {
                    inputs = ASK("{P_TransferToSpeak} Would you like to be transferred to Eliza so that you can speak to someone there?", "TRANSFER_S");
                    if (inputs == "no" || inputs == "No")
                    {
                        SAY("{S_Alright} Alright...");
                        return 0;
                    }
                    else
                    {
                        SAY("{S_Transferring} Transferring now...");
                        Transfer(true);
                        return 1;

                    }
                }
                
            }else
            {
                Transfer(false);
                SAY("{S_OutsideHours} If you have any questions about the interview please give us a call.");
                return 0;
            }
        }

        public bool TransferHours()                     //Checks to see if it is within the calling hours.  
        {
            DateTime Today = DateTime.Now;              //I use DateTime locally because I want to make sure someone doesn't just wait with the chat open until 10 at night.  
            if (Today.DayOfWeek == DayOfWeek.Friday && Today.Hour <= 17 && Today.Hour >= 8)
            {
                if (Today.Hour == 17 && Today.Minute > 30)
                {
                    return false;

                }
                else
                {
                    return true;
                }
            }
            else if (Today.DayOfWeek == DayOfWeek.Saturday && Today.Hour <= 17 && Today.Hour >= 12)
            {
                if (Today.Hour == 12 && Today.Minute < 30)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else if ((Today.DayOfWeek == DayOfWeek.Monday || Today.DayOfWeek == DayOfWeek.Tuesday || Today.DayOfWeek == DayOfWeek.Wednesday || Today.DayOfWeek == DayOfWeek.Thursday) && Today.Hour <= 18 && Today.Hour >= 8)
            {
                return true;
            }
            return false;                           //changed this to test transfer
        }

        public void EndCall(int end)                //End call section
        {
            if (end != 1)
            {
                DateTime Today = DateTime.Now;      //again, checking the time at this moment
                if (Today.Hour >= 5 && Today.Hour < 16)
                {
                    SAY("{S_Goodby_AM} We hope to be seeing you soon. Good luck and have a good day, " + "{NAME} " + name);
                }
                else if (Today.Hour >= 16 && Today.Hour < 20)
                {
                    SAY("{S_Goodby_PM} We hope to be seeing you soon. Good luck and have a good evening, " + "{NAME} " + name);
                }
                else
                {
                    SAY("{S_Goodby_PM2} We hope to be seeing you soon. Good luck and have a good night, " + "{NAME} " + name);
                }
            }
        }

        public void Transfer(bool valid)            //Logs transfer records.  I now realize that this has the same name as the other section.  
        {
            DateTime Today = DateTime.Now;
            xDoc.Root.Element("SESSION" + counter).Add(new XElement("TRANSFER", new XAttribute("DATE", Today.ToLongDateString()), new XAttribute("CURRENT_TIME", Today.Hour + ":" + Today.Minute + ":" + Today.Second), new XAttribute("VALID", valid)));
        }

        static void Main(string[] args)
        {
            Program pg = new Program();
            DateTime Today = DateTime.Now;
            counter = 1;                            //initialize counter
            filename = "Benjamin_Whippen_TEST_APP_" + Today.Year + "_" + Today.Month + "_" + Today.Day + ".xml";
            bool cont = true;                       //initialize bool for loop
            new XDocument(                          //create document
                    new XElement("LOG")
                )
                .Save(filename);
            xDoc = XDocument.Load(filename);        //load saved document

            while (cont) {                          //loop

                xDoc.Root.Add(new XElement("SESSION" + counter));

                pg.WorkFlow();                      //The whole workflow
                xDoc.Save(filename);                //saving changes
                Console.WriteLine("Do you wish to make another call?");
                string another = Console.ReadLine();
                if (another == "yes" || another == "Yes")
                {
                    cont = true;
                    counter++;
                } else
                {
                    cont = false;
                }
            }
            pg.SAY(xDoc.ToString());                //I was printing this during testing
            System.Threading.Thread.Sleep(5000);    //so it doesn't immediately close
        }
    }
}
